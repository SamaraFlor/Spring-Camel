package br.com.nava1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCamelApplicationTests {

	@Test
	void contextLoads() {
	}

}
